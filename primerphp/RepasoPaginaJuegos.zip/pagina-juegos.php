<!doctype html>
<html lang="es">
<head>

    <!-- ############## Características y elementos de carga de la página ################ -->

    <!-- Formatear e identificar caracteres -->
    <meta charset="UTF-8">

    <!-- IMPORTANTE para que la página se pueda ver y adaptar en diferentes dispositivos -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Título de la página (No se ve en el lienzo, pero sí que identifica la página). Se usa en SEO -->
    <title>Página juegos</title>
    <!-- Descripción SEO y para compartir -->
    <meta name="description" content="Descripción de la página">
    <!-- Imagen para compartir. Se usa en SEO y para compartir -->
    <meta name="image" content="./imagen.png">


    <link rel="stylesheet" type="text/css" href="./style.css">
    <script src="./functions.js"></script>

</head>

<body> <!-- Lienzo -->

<main>


    <section class="first-container">

        <div class="item">
            <h2>Recommended Events</h2>
            <div class="details item1">
                <img src="./t1.jpg" alt="">
            </div>
        </div>

        <div class="item">
            <h2>News Archive</h2>
            <div class="details item2">
                <img src="./trending3.jpg" alt="">
                <div>
                    <h3>Game of Thrones</h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipis
                    </p>
                    <a href="">View more</a>
                </div>
            </div>
        </div>


    </section>


    <section class="section-4">
        <h2>Our communities</h2>

        <div class="carousel">

            <div class="item">
                <img src="./image.jpg" alt="juegos">
                <div class="info">
                    <div>
                        <p>235</p>
                        <p>Posts</p>
                    </div>
                    <div>
                        <p>678</p>
                        <p>Members</p>
                    </div>
                </div>
                <button class="btn" type="button">Join Group</button>
            </div>

            <div class="item">
                <img src="./image.jpg" alt="juegos">
                <div class="info">
                    <div>
                        <p>235</p>
                        <p>Posts</p>
                    </div>
                    <div>
                        <p>678</p>
                        <p>Members</p>
                    </div>
                </div>
                <button class="btn" type="button">Join Group</button>
            </div>

            <div class="item">
                <img src="./image.jpg" alt="juegos">
                <div class="info">
                    <div>
                        <p>235</p>
                        <p>Posts</p>
                    </div>
                    <div>
                        <p>678</p>
                        <p>Members</p>
                    </div>
                </div>
                <button class="btn" type="button">Join Group</button>
            </div>

            <div class="item">
                <img src="./image.jpg" alt="juegos">
                <div class="info">
                    <div>
                        <p>235</p>
                        <p>Posts</p>
                    </div>
                    <div>
                        <p>678</p>
                        <p>Members</p>
                    </div>
                </div>
                <button class="btn" type="button">Join Group</button>
            </div>

        </div>

    </section>


</main>

</body>

</html>