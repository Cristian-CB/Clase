<!doctype html>
<html lang="es">
<head>

    <!-- ############## Características y elementos de carga de la página ################ -->

    <!-- Formatear e identificar caracteres -->
    <meta charset="UTF-8">

    <!-- IMPORTANTE para que la página se pueda ver y adaptar en diferentes dispositivos -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Título de la página (No se ve en el lienzo, pero sí que identifica la página). Se usa en SEO -->
    <title>PrimerPHP</title>
    <!-- Descripción SEO y para compartir -->
    <meta name="description" content="Descripción de la página">
    <!-- Imagen para compartir. Se usa en SEO y para compartir -->
    <meta name="image" content="./imagen.png">


    <link rel="stylesheet" type="text/css" href="./style.css">
    <script src="./functions.js"></script>

</head>

<body> <!-- Lienzo -->

<!-- Títulos, subtítulos... => h1, h2, h3, h4, h5, h6. SOLO Puede haber un H1 en tdo este archivo -->
<h1>TÍT H1</h1>
<h2>SUB H2</h2>
<h3>SUB H3</h3>
<h4>SUB H4</h4>
<h5>SUB H5</h5>
<h6>SUB H6</h6>

<p>
    Lorem ipsum dolor sit <strong>amet</strong>, <b>consectetur adipisicing elit</b>. At cupiditate explicabo ipsa
    nesciunt officia quas
    recusandae similique! Aliquid, at aut eligendi eum harum in omnis praesentium,
    <span>provident quasi qui quos?</span>
</p>


<div class="d-grid">
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque enim esse eum exercitationem ipsam molestiae
        mollitia perspiciatis quaerat quia quod, sint velit vero! Consequuntur deleniti, est exercitationem ipsum minima
        soluta!
    </p>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque enim esse eum exercitationem ipsam molestiae
        mollitia perspiciatis quaerat quia quod, sint velit vero! Consequuntur deleniti, est exercitationem ipsum minima
        soluta!
    </p>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque enim esse eum exercitationem ipsam molestiae
        mollitia perspiciatis quaerat quia quod, sint velit vero! Consequuntur deleniti, est exercitationem ipsum minima
        soluta!
    </p>
</div>


<div class="d-flex" style="margin-top: 100px">
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque enim esse eum exercitationem ipsam molestiae
        mollitia perspiciatis quaerat quia quod, sint velit vero! Consequuntur deleniti, est exercitationem ipsum minima
        soluta!
    </p>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque enim esse eum exercitationem ipsam molestiae
        mollitia perspiciatis quaerat quia quod, sint velit vero! Consequuntur deleniti, est exercitationem ipsum minima
        soluta!
    </p>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque enim esse eum exercitationem ipsam molestiae
        mollitia perspiciatis quaerat quia quod, sint velit vero! Consequuntur deleniti, est exercitationem ipsum minima
        soluta!
    </p>
</div>


<ol>
    <li>Item 1</li>
    <li>Item 2</li>
    <li>Item 3</li>
    <li>Item 4</li>
    <li>Item 5</li>
</ol>

<ul>
    <li>Item 1</li>
    <li>Item 2</li>
    <li>Item 3</li>
    <li>Item 4</li>
    <li>Item 5</li>
</ul>


<!--
NAME = Identificación de qué formulario es enviado, luego cuando recogemos los datos en el BACK PHP
ACTION = Acción. Donde vamos a enviar los datos del formulario.
METHOD (GET /POST)
    - GET => Es para realizar búsquedas con datos no sensibles
    - POST => Parecido al GET. Los datos de aquí van encriptados (HTTP) a un servidor.
-->
<form name="" action="" method="post">

    <div class="item-form">
        <label for="full_name">Nombre completo</label>
        <input type="text" name="" id="full_name" placeholder="Pepe" required>
    </div>

    <div class="item-form">
        <label for="email">Correo electrónico</label>
        <input type="email" name="" id="email" value="pepe@gmail.com" disabled>
    </div>

    <div>

        <input type="password" name="">
        <input type="tel" name="">
        <input type="checkbox" name="">
        <input type="radio" name="">
        <input type="hidden" name="">
        <input type="date" name="">
        <input type="datetime-local" name="">
        <input type="button" name="">
        <input type="file" name="">
        <input type="submit" name="">
        <input type="reset" name="">
    </div>

    <div class="item-form">
        <label for="message">Mensaje</label>
        <textarea name="" id="message" cols="30" rows="10"></textarea>
    </div>

    <div class="item-form">
        <button type="submit">
            Enviar
        </button>
    </div>

</form>


<header></header>

<main>
    <section></section>
    <section></section>
    <section></section>
    <section></section>
</main>

<footer></footer>


</body>

</html>